#include "coord.h"

int Coord::m_nb_col = 0;
